//Less dirty Code\\
//Colors
			if ([self saverModeActive]){
fill.backgroundColor = YELLOW;
//fill.backgroundColor = LPM_Color; //That's should return correctly formatted value.

			}else{
				if (isCharging){
fill.backgroundColor = GREEN;
//fill.backgroundColor = C_Color;

				}else{
					if (actualPercentage >= 20)
fill.backgroundColor = [UIColor labelColor];
//fill.backgroundColor = [B_Color];
					else
fill.backgroundColor = RED;
//fill.backgroundColor = LB_Color;

				}
			}

			[self addSubview:fill];
		}
	}

//-----------------------------------------------
//Loading Frame
	[icon setImage:[UIImage imageWithData:batteryImage]];
	[self updateIconColor];
	customViewApplied=YES;
}
//-----------------------------------------------
%new
// Load colors in conditions
-(void)updateIconColor{
	if (!PXLEnabled)
		return;

	icon.image = [icon.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
	fill.image = [fill.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];

	if (![self saverModeActive]){
		if (isCharging){
			[icon setTintColor:GREEN];
			[fill setTintColor:GREEN];
//			[icon setTintColor:C_Color];
//			[fill setTintColor:C_Color];
		}else{
			if (actualPercentage >= 20){
				[icon setTintColor:[UIColor labelColor]];
				[fill setTintColor:[UIColor labelColor]];
//				[icon setTintColor:B_Color];
//				[fill setTintColor:B_Color];
			}else{
				[icon setTintColor:[UIColor labelColor]];
				[fill setTintColor:fill.backgroundColor = RED];
//           	[icon setTintColor:fill.backgroundColor = B_Color];
//              [fill setTintColor:fill.backgroundColor = LB_Color];
				if (actualPercentage >= 10){
					[icon setTintColor:[UIColor labelColor]];
					[fill setTintColor:[UIColor labelColor]];
//                  [icon setTintColor:B_Color];
//                  [fill setTintColor:B_Color];
				}else{
					[icon setTintColor:fill.backgroundColor = RED];
					[fill setTintColor:fill.backgroundColor = RED];
//					[icon setTintColor:fill.backgroundColor = LB_Color];
//					[fill setTintColor:fill.backgroundColor = LB_Color];

				}
			}
		}
	}else{
		if (isCharging){
			[icon setTintColor:GREEN];
			[fill setTintColor:GREEN];
//			[icon setTintColor:fill.backgroundColor = C_Color];
//			[fill setTintColor:fill.backgroundColor = C_Color];

		}else{
			[icon setTintColor:YELLOW];
            [fill setTintColor:YELLOW];
//			[fill setTintColor:fill.backgroundColor = LPM_Color];
//			[fill setTintColor:fill.backgroundColor = LPM_Color];
		}
	}
}