//Old Code dirty\\
if (![self saverModeActive]){
		if (isCharging){
//			[icon setTintColor:GREEN];
			//[fill setTintColor:GREEN];
			[icon setTintColor:C_Color];
			[fill setTintColor:C_Color];
		}else{
			if (actualPercentage >= 20){
//				[icon setTintColor:[UIColor labelColor]];
				//[fill setTintColor:[UIColor labelColor]];
				[icon setTintColor:B_Color];
				[fill setTintColor:B_Color];

			}else{
//				[icon setTintColor:[UIColor labelColor]];
				//[fill setTintColor:fill.backgroundColor = RED];
				[icon setTintColor:fill.backgroundColor = LB_Color];
				[fill setTintColor:fill.backgroundColor = LB_Color];

				if (actualPercentage >= 10){
			//	[icon setTintColor:[UIColor labelColor]]; // note to self label color is white
			//	[fill setTintColor:[UIColor labelColor]];
				[icon setTintColor:B_Color];
				[fill setTintColor:B_Color];
					//[fill setTintColor:[UIColor labelColor]]; %10< has no tick

				}else{
//					[icon setTintColor:fill.backgroundColor = RED];
					[icon setTintColor:fill.backgroundColor = LB_Color];
					[fill setTintColor:fill.backgroundColor = LB_Color];
				}
			}
		}
	}else{
		if (isCharging){
//			[icon setTintColor:GREEN];
			//[fill setTintColor:GREEN];
			[icon setTintColor:fill.backgroundColor = C_Color];
			[fill setTintColor:fill.backgroundColor = C_Color];

		}else{
//			[icon setTintColor:YELLOW];
            //[fill setTintColor:YELLOW];
			[fill setTintColor:fill.backgroundColor = LPM_Color];
			[fill setTintColor:fill.backgroundColor = LPM_Color];

		}
	}
}